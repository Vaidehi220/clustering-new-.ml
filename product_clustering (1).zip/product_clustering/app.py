# app.py
from flask import Flask, request, render_template
import joblib
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
import os

# Load models and data
vectorizer = joblib.load("model/tfidf_vectorizer.pkl")
svd = joblib.load("model/svd_transformer.pkl")
kmeans = joblib.load("model/kmeans_model.pkl")
df = pd.read_pickle("model/product_data.pkl")

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        user_input = request.form.get("description")

        if not user_input:
            return render_template("index.html", error="Please enter a product description.")

        # Preprocess and transform
        tfidf_vec = vectorizer.transform([user_input])
        svd_vec = svd.transform(tfidf_vec)
        cluster = kmeans.predict(svd_vec)[0]

        # Find similar products in the same cluster
        df_cluster = df[df["Cluster"] == cluster]
        tfidf_cluster = vectorizer.transform(df_cluster['Description'])
        sim_scores = cosine_similarity(tfidf_vec, tfidf_cluster).flatten()
        top_indices = sim_scores.argsort()[::-1][:5]
        recommendations = df_cluster.iloc[top_indices]['Description'].tolist()

        return render_template("index.html", 
                               cluster=cluster, 
                               recommendations=recommendations, 
                               user_input=user_input)

    return render_template("index.html")

if __name__ == "__main__":
    os.makedirs("model", exist_ok=True)
    app.run(debug=True)

